# Daily Design — press & sponsor kit

**Daily Design** · https://studios.greatcreations.art/daily-design/ · X: [@GreatCreations_](https://x.com/GreatCreations_) · Facebook: [Daily Design](https://www.facebook.com/profile.php?id=61595851597605)
Press & sponsors: **dailydesign@greatcreations.ca**
Online: https://studios.greatcreations.art/daily-design/about.html#press-kit

## Boilerplate (from the About page)
Daily Design is a public archive of AI design research digests: four editions a day on how AI is changing creative work, across image, video, 3D, code/UI, sound, games and mashups. Every edition links straight to the original creators and sources, and the whole archive is searchable by medium, type, edition and date. Published since Oct 16, 2026.

## For press
Use the logo with wordmark. Mascot: **Dee Dee** (always "Dee Dee"). Each edition has its own 1200×630 share card (`system/share-card-example-1200x630.jpg`).

## For sponsors
Sponsors never affect what Daily Design picks or how it ranks. Ad space runs on the index and edition pages. Contact dailydesign@greatcreations.ca.

## Logos (supplied as artwork — no font install needed)
All PNGs are transparent; `-on-light` versions have dark ink for light backgrounds.
- **Logo with wordmark:** the DD icon beside the one Daily Design wordmark, the exact live site header "Daily *Design*" (a capture, never retyped) — `logos/dd-logo-wordmark-transparent.png` / `-on-light-transparent.png` (3355×606) and `logos/dd-logo-wordmark.svg` / `-on-light.svg` (vector icon + the same header capture embedded).
- **Official standalone mark:** the DD rounded-square icon — `logos/dd-icon.svg`, `logos/dd-icon-2048-transparent.png` (16px version: `dd-favicon-16.svg`).
- **Wordmark:** the live header "Daily *Design*", captured from the site — `logos/dd-wordmark-original-site*-transparent.png` (PNG only). This is the only wordmark; there is no other lockup.
- **Dee Dee:** `mascot/deedee-plain`, `deedee-morning`, `deedee-noon`, `deedee-best`, `deedee-hottest` — each as SVG and 2048px transparent PNG. The plain pose is the existing art with props removed.
- `previews/` — every mark on dark (#09090c) and light (#ffffff).

## Colours (CSS variables, site.css)
Amber/accent #f5a524 · aqua #22e0cf · violet #9b6bff · flame #ff5a2e · gold #ffcf5a · pill #0b0b0e
- Title gradient: `linear-gradient(90deg,#f5a524,#22e0cf 35%,#9b6bff 68%,#ff5a2e)`
- Icon gradient: `linear-gradient(135deg,#f5a524,#ff5a2e 55%,#9b6bff)` (glyph #0b0b0e)
- Save badge: `linear-gradient(110deg,#f5a524 0%,#ffcf5a 30%,#fff3cf 45%,#ffcf5a 55%,#22e0cf 100%)`

## Type
The site loads no web fonts; it uses system stacks (licensed with each operating system, not redistributable). The logos are supplied as artwork.
- Display: `font-family: "Iowan Old Style","Palatino Linotype",Palatino,"Book Antiqua",Georgia,serif;` 400, italic for the gradient word.

## Usage (clear space and minimum size: FINAL, approved Nov 4, 2026)
- Clear space: at least the cap height of "D" on every side.
- Minimum size: logos 120px / 30mm wide; icon 16px (use dd-favicon-16.svg at that size).
- Use light-ink versions on dark (#09090c) and `-on-light` versions on light.
- Don't recolour, reorder or flatten the gradients; don't stretch, skew, outline, shadow or rotate marks; don't retype the logos in other fonts; don't call the mascot "Dee".
