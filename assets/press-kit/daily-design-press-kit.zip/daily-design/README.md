# Daily Design — press & sponsor kit

**Daily Design** · https://studios.greatcreations.art/daily-design/ · X: [@GreatCreations_](https://x.com/GreatCreations_)
Press & sponsors: **dailydesign@greatcreations.ca**
Online: https://studios.greatcreations.art/daily-design/about.html#press-kit

## Boilerplate (from the About page)
Daily Design is a public archive of AI design research digests: four editions a day on how AI is changing creative work, across image, video, 3D, code/UI, sound, games and mashups. Every edition links straight to the original creators and sources, and the whole archive is searchable by medium, type, edition and date. Published since Oct 16, 2026.

## For press
Use the primary logo. Mascot: **Dee Dee** (always "Dee Dee"). Each edition has its own 1200×630 share card (`system/share-card-example-1200x630.jpg`).

## For sponsors
Sponsors never affect what Daily Design picks or how it ranks. Ad space runs on the index and edition pages. Contact dailydesign@greatcreations.ca.

## Logos (supplied as artwork — no font install needed)
All PNGs are transparent; `-on-light` versions have dark ink for light backgrounds.
- **Primary logo:** DD icon + the site wordmark, captured from the live site element at high resolution — `logos/dd-logo-primary-transparent.png`, `logos/dd-logo-primary-on-light-transparent.png` (PNG only; the site draws it as an icon plus live text).
- **Official standalone mark:** the DD rounded-square icon — `logos/dd-icon.svg`, `logos/dd-icon-2048-transparent.png` (16px version: `dd-favicon-16.svg`).
- **Original site wordmark:** the live header "Daily *Design*", captured from the site — `logos/dd-wordmark-original-site*-transparent.png` (PNG only).
- **Title lockup (secondary):** outlined SVG + PNG — `logos/dd-title-lockup*.svg/png`.
- **Dee Dee:** `mascot/deedee-plain`, `deedee-morning`, `deedee-noon`, `deedee-best`, `deedee-hottest` — each as SVG and 2048px transparent PNG. The plain pose is the existing art with props removed.
- `previews/` — every mark on dark (#09090c) and light (#ffffff).

## Colours (CSS variables, site.css)
bg #09090c · bg2 #111117 · card #15151c · ink #f1efe9 · muted #a7a39a · dim #76736c · amber/accent #f5a524 · aqua #22e0cf · violet #9b6bff · flame #ff5a2e · gold #ffcf5a · pill #0b0b0e
- Title gradient: `linear-gradient(90deg,#f5a524,#22e0cf 35%,#9b6bff 68%,#ff5a2e)`
- Icon gradient: `linear-gradient(135deg,#f5a524,#ff5a2e 55%,#9b6bff)` (glyph #0b0b0e)
- Save badge: `linear-gradient(110deg,#f5a524 0%,#ffcf5a 30%,#fff3cf 45%,#ffcf5a 55%,#22e0cf 100%)`

## Type
The site loads no web fonts; it uses system stacks (licensed with each operating system, not redistributable). The logos are supplied as artwork.
- Display: `font-family: "Iowan Old Style","Palatino Linotype",Palatino,"Book Antiqua",Georgia,serif;` 400, italic for the gradient word.
- Body/UI: `font-family: ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;` 400 body, 600 buttons, 700 labels/wordmark, 800 badge.
- Mono: `font-family: ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;`

## Usage (clear space and minimum size: FINAL, approved Nov 4, 2026)
- Clear space: at least the cap height of "D" on every side.
- Minimum size: logos 120px / 30mm wide; icon 16px (use dd-favicon-16.svg at that size).
- Use light-ink versions on dark and `-on-light` versions on light.
- Don't recolour, reorder or flatten the gradients; don't stretch, skew, outline, shadow or rotate marks; don't retype the logos in other fonts; don't call the mascot "Dee".
